package com.focuslock.strict

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.compose.setContent

class BlockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val isSite = intent.getBooleanExtra("site", false)
        val raw = intent.getStringExtra("target").orEmpty()
        val target = if (isSite) raw else try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(raw, 0)).toString()
        } catch (_: Exception) { raw }
        onBackPressedDispatcher.addCallback(this) { homeAndFinish() }
        setContent { AppTheme { BlockScreen(isSite, target) { homeAndFinish() } } }
    }

    private fun homeAndFinish() { Guard.goHome(this); finish() }

    override fun onStop() { super.onStop(); finish() }
}
