package com.focuslock.strict

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.compose.ui.res.stringResource

/** شاشة كلمة السر فوق الإعدادات الحساسة أو التطبيقات المحمية. */
class UnlockActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val mode = intent.getStringExtra("mode") ?: "settings"
        val target = intent.getStringExtra("target")
        val label = target?.let {
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it, 0)).toString() } catch (_: Exception) { it }
        }.orEmpty()
        onBackPressedDispatcher.addCallback(this) { cancel() }
        setContent {
            AppTheme {
                val isApp = mode == "app"
                PasswordGate(
                    title = stringResource(if (isApp) R.string.unlock_app_title else R.string.unlock_settings_title),
                    subtitle = if (isApp) stringResource(R.string.unlock_app_sub, label) else stringResource(R.string.unlock_settings_sub),
                    onSuccess = {
                        if (isApp && target != null) Guard.appGrace[target] = System.currentTimeMillis() + 2 * T.MIN
                        else Prefs(this).graceUntil = System.currentTimeMillis() + 5 * T.MIN
                        finish()
                    },
                    onCancel = { cancel() }
                )
            }
        }
    }

    private fun cancel() { Guard.goHome(this); finish() }

    override fun onStop() { super.onStop(); if (!isFinishing) finish() }
}
