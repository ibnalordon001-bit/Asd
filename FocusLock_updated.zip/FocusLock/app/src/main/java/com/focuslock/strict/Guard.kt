package com.focuslock.strict

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager

object Guard {
    /** حزم الإعدادات التي نحميها أثناء الوضع الصارم. */
    val SETTINGS = setOf("com.android.settings", "com.samsung.android.settings")

    /** مهلة السماح بعد إدخال كلمة السر لتطبيق محمي (ذاكرة فقط). */
    val appGrace = mutableMapOf<String, Long>()

    /** كلمات شاشة خيارات المطور (تُستثنى من الحماية خلال مهلة الـ72 ساعة). */
    val DEV_KEYWORDS = listOf(
        "developer options", "development settings", "developmentsettings",
        "خيارات المطور", "خيارات المطورين", "خيارات المطوّر", "للمطورين"
    )

    /** كلمات تظهر في عنوان شاشات الإعدادات الحساسة (عربي/إنجليزي). */
    val SENSITIVE_KEYWORDS = listOf(
        "developer options", "development settings", "developmentsettings",
        "device admin", "deviceadmin", "device administrators",
        "accessibility",
        "خيارات المطور", "خيارات المطورين",
        "مشرف الجهاز", "مشرفو الجهاز", "مسؤولو الجهاز", "تطبيقات مشرف",
        "إمكانية الوصول", "امكانية الوصول", "سهولة الاستخدام"
    )

    /** معرّفات شريط العنوان في المتصفحات المعروفة. */
    val URL_BAR_IDS: Map<String, List<String>> = mapOf(
        "com.android.chrome" to listOf("com.android.chrome:id/url_bar"),
        "com.chrome.beta" to listOf("com.chrome.beta:id/url_bar"),
        "com.brave.browser" to listOf("com.brave.browser:id/url_bar"),
        "com.microsoft.emmx" to listOf("com.microsoft.emmx:id/url_bar"),
        "com.kiwibrowser.browser" to listOf("com.kiwibrowser.browser:id/url_bar"),
        "com.opera.browser" to listOf("com.opera.browser:id/url_field"),
        "com.sec.android.app.sbrowser" to listOf(
            "com.sec.android.app.sbrowser:id/location_bar_edit_text",
            "com.sec.android.app.sbrowser:id/sbrowser_url_bar"
        ),
        "org.mozilla.firefox" to listOf(
            "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
            "org.mozilla.firefox:id/url_bar_title"
        ),
        "com.duckduckgo.mobile.android" to listOf("com.duckduckgo.mobile.android:id/omnibarTextInput")
    )

    /** تطبيقات لا تُحظر ولا تُقفل أبداً: الهاتف والطوارئ والرئيسية ولوحة المفاتيح وواجهة النظام. */
    fun protectedPackages(ctx: Context): Set<String> {
        val s = mutableSetOf(
            ctx.packageName, "com.android.systemui", "com.android.phone",
            "com.android.server.telecom", "com.android.emergency",
            "com.google.android.dialer", "com.android.dialer",
            "com.samsung.android.dialer", "com.samsung.android.incallui", "com.android.incallui"
        )
        val pm = ctx.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .forEach { s.add(it.activityInfo.packageName) }
        ctx.getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s.add(it) }
        ctx.getSystemService(InputMethodManager::class.java)?.enabledInputMethodList
            ?.forEach { s.add(it.packageName) }
        return s
    }

    fun browserPackages(ctx: Context): Set<String> {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE)
        return ctx.packageManager.queryIntentActivities(i, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName }.toSet() + URL_BAR_IDS.keys
    }

    /**
     * المتصفحات الحقيقية فقط (المثبتة حالياً وأي متصفح يُثبَّت لاحقاً): الرابط بلا نطاق (https:// و http://)
     * لا تطابقه إلا التطبيقات التي تفتح أي موقع، أما التطبيقات التي تفتح روابط نطاقها الخاص
     * (يوتيوب، فيسبوك...) فلا تظهر هنا. نضيف أيضاً المتصفح الافتراضي إن وُجد.
     */
    fun realBrowserPackages(ctx: Context): Set<String> {
        val pm = ctx.packageManager
        val out = mutableSetOf<String>()
        for (url in listOf("https://", "http://")) {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)
            try { pm.queryIntentActivities(i, PackageManager.MATCH_ALL).forEach { out.add(it.activityInfo.packageName) } }
            catch (_: Exception) { }
        }
        try {
            val sel = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
            pm.queryIntentActivities(sel, PackageManager.MATCH_ALL).forEach { out.add(it.activityInfo.packageName) }
        } catch (_: Exception) { }
        return out + URL_BAR_IDS.keys
    }

    fun goHome(ctx: Context) {
        ctx.startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** يحوّل رابطاً أو نصاً مكتوباً إلى نطاق نظيف، أو null إن لم يكن نطاقاً. */
    fun normalizeDomain(raw: String): String? {
        val s = raw.trim().lowercase()
        if (s.isEmpty() || s.any { it.isWhitespace() }) return null
        val noScheme = if ("://" in s) s.substringAfter("://") else s
        val host = noScheme.takeWhile { it != '/' && it != '?' && it != '#' && it != ':' }
            .removePrefix("www.").trimEnd('.')
        return if (host.length >= 3 && '.' in host && !host.startsWith('.')) host else null
    }

    fun isBlocked(host: String, sites: Set<String>): Boolean =
        sites.any { host == it || host.endsWith(".$it") }
}
