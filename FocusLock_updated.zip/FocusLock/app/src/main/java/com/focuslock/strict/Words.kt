package com.focuslock.strict

import java.text.Normalizer
import java.util.regex.Pattern

/**
 * مطابقة الكلمات المحظورة.
 *
 * القاعدة الافتراضية: الكلمة تُطابَق ككلمة كاملة فقط (لا داخل كلمة أخرى)، فلا تُحظر "Essex" بسبب "sex"
 * ولا "class" بسبب "ass". مع السماح بصيغ بسيطة جداً:
 *  - الإنجليزية: جمع بـ s / es.
 *  - العربية (للكلمات من 3 أحرف فأكثر): سوابق مثل (ال، وال، بال، كال، لل، و، ف، ب، ك، ل) ولواحق مثل (ات، ون، ين، ها، هم، ك، ي...).
 *
 * للتحكم اليدوي: أضف * في أول الكلمة أو آخرها لفتح الحد من تلك الجهة:
 *   porn*   تطابق porn و pornhub و pornography
 *   *porn   تطابق hardporn
 *   *porn*  تطابق أي نص يحتوي porn داخله
 *
 * تتجاهل الحالة والتشكيل والتطويل والمحارف الخفية، وتوحّد الأشكال المتشابهة (أ/إ/آ، ى/ي، ة/ه، ک/ك، ی/ي)
 * وتكشف التحايل بتباعد الحروف مثل "p o r n" أو "p.o.r.n" دون أن تلصق كلمات مختلفة ببعضها.
 */
object Words {
    private const val MIN_LEN = 2
    private const val MAX_TEXT = 8_000

    fun norm(s: CharSequence): String {
        // NFKD: يحوّل الأحرف العريضة (ｐｏｒｎ) والرياضية (𝐩𝐨𝐫𝐧) وأشكال الحروف العربية المعروضة إلى حروفها الأصلية
        val src = Normalizer.normalize(s.toString().lowercase(), Normalizer.Form.NFKD)
        val sb = StringBuilder(src.length)
        for (ch in src) {
            val type = Character.getType(ch)
            if (type == Character.NON_SPACING_MARK.toInt()) continue                 // تشكيل وعلامات التفكيك
            if (ch == '\u0640') continue                                              // تطويل
            if (ch in '\u200B'..'\u200F' || ch in '\u202A'..'\u202E' || ch in '\u2066'..'\u2069' ||
                ch == '\u2060' || ch == '\u00AD' || ch == '\uFEFF'
            ) continue                                                                // محارف خفية
            sb.append(
                when (ch) {
                    'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                    'ى', 'ی', 'ئ' -> 'ي'
                    'ؤ' -> 'و'
                    'ة' -> 'ه'
                    'ک' -> 'ك'
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    private fun isArabic(c: Char) = c in '\u0621'..'\u064A'
    private fun isLatin(c: Char) = c in 'a'..'z'

    // سوابق ولواحق عربية شائعة (بعد التوحيد: ة صارت ه)
    private const val AR_PREFIX = "(?:[وف]?(?:لل|[بكل]?(?:ال)?))"
    private const val AR_SUFFIX = "(?:ها|هم|هن|هما|كم|كن|كما|نا|ات|ان|ين|ون|ه|ك|ي)?"
    private const val SEP = "[^\\p{L}\\p{N}]+"

    private fun leftBoundary(c: Char) = when {
        Character.isLetter(c) -> "(?<!\\p{L})"
        Character.isDigit(c) -> "(?<![\\p{L}\\p{N}])"
        else -> ""
    }

    private fun rightBoundary(c: Char) = when {
        Character.isLetter(c) -> "(?!\\p{L})"
        Character.isDigit(c) -> "(?![\\p{L}\\p{N}])"
        else -> ""
    }

    private fun letterCount(s: String) = s.count { it.isLetter() }

    /** يبني نمطاً لكلمة واحدة (أو عبارة) من نص المستخدم، أو null إن لم تصلح. */
    private fun buildPattern(raw: String): String? {
        var w = raw.trim()
        val openLeft = w.startsWith("*")
        val openRight = w.endsWith("*")
        w = w.trim('*').trim()
        w = norm(w).trim()
        if (w.length < MIN_LEN) return null
        val parts = w.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return null

        val first = parts.first()
        val last = parts.last()
        val body = parts.joinToString(SEP) { Pattern.quote(it) }

        val left = if (openLeft) "" else leftBoundary(first.first())
        val right = if (openRight) "" else rightBoundary(last.last())

        val singleWord = parts.size == 1
        val arabic = isArabic(last.last()) && letterCount(last) >= 3
        val arabicFirst = isArabic(first.first()) && letterCount(first) >= 3
        val latin = isLatin(last.last()) && letterCount(last) >= 3

        val pre = if (!openLeft && arabicFirst) AR_PREFIX else ""
        val suf = when {
            openRight -> ""
            arabic -> AR_SUFFIX
            latin -> "(?:s|es)?"
            else -> ""
        }
        var core = "$pre$body$suf"
        // جمع المؤنث العربي: مدرسة (مدرسه) ← مدرسات
        if (singleWord && !openRight && arabic && last.endsWith("ه") && last.length >= 4) {
            core = "(?:$core|$pre${Pattern.quote(last.dropLast(1))}ات)"
        }
        return "$left$core$right"
    }

    class Matcher(words: Set<String>) {
        private val regex: Pattern?

        init {
            val patterns = words.mapNotNull { buildPattern(it) }.distinct()
            regex = if (patterns.isEmpty()) null else try {
                Pattern.compile(patterns.joinToString("|") { "(?:$it)" })
            } catch (_: Exception) {
                // احتياط: إن فشل الدمج نبني كل نمط بمفرده ونتجاهل التالف
                val ok = patterns.filter { p -> try { Pattern.compile(p); true } catch (_: Exception) { false } }
                if (ok.isEmpty()) null else Pattern.compile(ok.joinToString("|") { "(?:$it)" })
            }
        }

        val isEmpty: Boolean get() = regex == null

        fun matches(text: CharSequence?): Boolean {
            val rx = regex ?: return false
            if (text.isNullOrEmpty()) return false
            val t = norm(text.take(MAX_TEXT))
            if (rx.matcher(t).find()) return true
            return matchesSpacedOut(t, rx)
        }

        /**
         * تحايل مثل "p o r n" أو "p.o.r.n": نجمع فقط سلاسل من 3 أحرف منفردة متتالية أو أكثر
         * ونفحص الناتج ككلمة مستقلة. لا نلصق الكلمات العادية ببعضها (فلا تُطابق "top or nothing" كلمة porn).
         */
        private fun matchesSpacedOut(t: String, rx: Pattern): Boolean {
            val run = StringBuilder()
            var count = 0
            var i = 0
            val n = t.length
            fun flush(): Boolean {
                val hit = count >= 3 && rx.matcher(run).find()
                run.setLength(0); count = 0
                return hit
            }
            while (i < n) {
                if (t[i].isLetterOrDigit()) {
                    var j = i
                    while (j < n && t[j].isLetterOrDigit()) j++
                    if (j - i == 1) {
                        run.append(t[i]); count++
                    } else if (flush()) return true
                    i = j
                } else i++
            }
            return flush()
        }
    }
}
