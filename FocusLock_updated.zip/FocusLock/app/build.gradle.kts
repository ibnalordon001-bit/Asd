plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.focuslock.strict"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.focuslock.strict"
        minSdk = 26
        targetSdk = 34
        // دقائق منذ 1970: تزيد دائماً مع كل بناء، حتى لو أُعيد إنشاء المستودع، فلا يُرفض التحديث كتخفيض إصدار
        versionCode = (System.currentTimeMillis() / 60_000L).toInt()
        versionName = "1.1"
    }
    // مفتاح توقيع ثابت: يضمن أن التحديثات تُثبَّت فوق بعضها وتحتفظ بصلاحية مالك الجهاز
    signingConfigs {
        create("fixed") {
            storeFile = file("focuslock.keystore")
            storePassword = "focuslock123"
            keyAlias = "focuslock"
            keyPassword = "focuslock123"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("fixed") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
}
